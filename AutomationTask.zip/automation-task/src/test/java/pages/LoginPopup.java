package pages;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
 
public class LoginPopup {
 
private WebDriver driver;
	
	public LoginPopup(WebDriver driver) {
			this.driver = driver;
	}
	
    

    // Method to check Page logo
    public void verifyLoginTitle() {
    WebElement e = driver.findElement(By.xpath("//*[@id=\"login-modal-label\"]"));
    Assert.assertNotNull(e);
    }
    
 // Method to type User Name
    public void typeUsername(String Id){
    driver.findElement(By.id("Email")).sendKeys(Id);
}

// Method to type Password
    public void typePassword(String PasswordValue){
    driver.findElement(By.id("Password")).sendKeys(PasswordValue);
}
    

// Method to click LoginIn Button
    public void clickSignIn(){
    driver.findElement(By.className("btn btn-default")).click();
  }
         
         
// Locator for Log in submit button
 // By  visible = By.linkText("Log in");
              
     
// Method to check Submit text
 public String submitText() {
 return driver.findElement(By.linkText("Log in")).getText();
         } 
              
    // Method to check Login Submit button
     public void verifyLoginSubmit() {
    	 Assert.assertNotNull(driver.findElement(By.xpath("//*[@type=\"submit\"]")));
    	 
     }
        
}
    