package pages;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
 
public class MainPage {
 
private WebDriver driver;
	
	public MainPage(WebDriver driver) {
			this.driver = driver;
	}
	        
     
    // Method to check HomePage Title
         public String verifyHomepageTitle() {
    	 return driver.getTitle();
     }
    
      // Method to click Run Button
         public void clickRun(){
         driver.findElement(By.xpath("//*[@id=\"run-button\"]")).click();
         }
         
       // Method to click Save Button
         public void clickSave(){
         driver.findElement(By.xpath("//*[@id=\"save-button\"]")).click();
         }
         
         
  // Locator for Output Message
         //By ErrorMessage=By.xpath("//*[@id=\"login_button_container\"]/div/form/div[3]");
         By OutputText = By.xpath("//*[@id=\"output\"]");
     
    // Method to check ErrorMessge
         public String getOutputText() {
    	 return driver.findElement(OutputText).getText();
    }
    
        public void verifyOutputTextDisplayed(String expectedMessage) {
    	String outputMsg = getOutputText();
    	Assert.assertEquals("Compare error message ["+expectedMessage+"] ", expectedMessage, outputMsg);
    }
}