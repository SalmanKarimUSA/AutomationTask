package test;


import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import pages.MainPage;
import pages.LoginPopup;

public class AutomationTask {

WebDriver driver;
MainPage mainPage;
LoginPopup loginPopup;

@BeforeClass
public void setUp()
{
	
System.setProperty("webdriver.chrome.driver", "C:\\Driver\\chromedriver.exe");
driver=new ChromeDriver();
driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
driver.manage().window().maximize();
driver.get("https://dotnetfiddle.net/");
}


@Test(description="This method validates Output Text")
public void Test1()
{
mainPage = new MainPage(driver);
mainPage.clickRun();
mainPage.verifyOutputTextDisplayed("Hello World");
System.out.println("The Output Window text is - " + mainPage.getOutputText());

}

@Test(description="If your first name starts with letter �Q-R-S-T-U�):")
public void Test2()
{
	loginPopup = new LoginPopup(driver);
	mainPage = new MainPage(driver);
	mainPage.clickSave();
	loginPopup.verifyLoginTitle();
	loginPopup.verifyLoginSubmit();
	loginPopup.verifyLoginSubmit();

    System.out.println(" The text display on Submit button is -"+loginPopup.submitText());
}


@AfterClass
public void tearDown()
{
driver.quit();
}

}