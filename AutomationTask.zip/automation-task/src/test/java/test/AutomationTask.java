package test;


import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import pages.MainPage;
import pages.LoginPopup;

public class AutomationTask {

WebDriver driver;
MainPage mainPage;
LoginPopup loginPopup;

@BeforeClass
public void setUp()
{
	
System.setProperty("webdriver.chrome.driver", "C:\\Driver\\chromedriver.exe");
// Open Chrome Browser
driver=new ChromeDriver();
driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
driver.manage().window().maximize();
// Navigate to https://dotnetfiddle.net/
driver.get("https://dotnetfiddle.net/");
}


@Test(description="This method validates Output Text")
public void Test1()
{
mainPage = new MainPage(driver);
//Click �Run� button
mainPage.clickRun();
//Check Output window (�Hello World� text is expected)
mainPage.verifyOutputTextDisplayed("Hello World");
//Print the output message
System.out.println("The Output Window text is - " + mainPage.getOutputText());

}

@Test(description="If your first name starts with letter �Q-R-S-T-U�):")
public void Test2()
{
	loginPopup = new LoginPopup(driver);
	mainPage = new MainPage(driver);
	//Click �Save� button
	mainPage.clickSave();
   //Check that �Log In� window appeared showing Log In header
	loginPopup.verifyLoginTitle();
	//Check the Log in submit button 
	loginPopup.verifyLoginSubmit();
	//Check the login submit button text
	loginPopup.submitText();
    //print Login submit button text
    System.out.println(" The text display on Submit button is -"+loginPopup.submitText());
}


@AfterClass
public void tearDown()
{
driver.quit();
}

}